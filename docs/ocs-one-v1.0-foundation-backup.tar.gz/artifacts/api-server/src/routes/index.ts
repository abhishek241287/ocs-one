import { Router, type IRouter } from "express";
import { requireAuth } from "../middleware/auth";
import healthRouter from "./health";
import authRouter from "./auth";
import productMasterRouter from "./masters/products";
import cellMasterRouter from "./masters/cells";
import bmsMasterRouter from "./masters/bms";
import cabinetMasterRouter from "./masters/cabinets";
import connectorMasterRouter from "./masters/connectors";
import cableMasterRouter from "./masters/cables";
import busbarMasterRouter from "./masters/busbars";
import chargerMasterRouter from "./masters/chargers";
import testEquipmentMasterRouter from "./masters/test-equipment";
import manufacturingRouter from "./manufacturing/index";
import cellsRouter from "./cells/index";
import logisticsRouter from "./logistics/index";
import dashboardRouter from "./dashboard/index";
import reportsRouter from "./reports/index";

const router: IRouter = Router();

// ─── Public routes (no auth required) ────────────────────────────────────────
router.use(healthRouter);
router.use("/auth", authRouter);

// ─── All routes below require a valid session ─────────────────────────────────
router.use(requireAuth);

// Engineering Masters
router.use("/masters/products", productMasterRouter);
router.use("/masters/cells", cellMasterRouter);
router.use("/masters/bms", bmsMasterRouter);
router.use("/masters/cabinets", cabinetMasterRouter);
router.use("/masters/connectors", connectorMasterRouter);
router.use("/masters/cables", cableMasterRouter);
router.use("/masters/busbars", busbarMasterRouter);
router.use("/masters/chargers", chargerMasterRouter);
router.use("/masters/test-equipment", testEquipmentMasterRouter);

// Manufacturing
router.use("/manufacturing", manufacturingRouter);

// Cell Lifecycle
router.use("/cells", cellsRouter);

// Logistics
router.use("/logistics", logisticsRouter);

// Director Dashboard
router.use("/dashboard", dashboardRouter);

// Reports
router.use("/reports", reportsRouter);

export default router;
